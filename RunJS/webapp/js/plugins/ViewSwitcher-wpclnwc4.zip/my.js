ViewSwitcher = (function() {

	var PT = ViewSwitcher.prototype;

	var instance;

	PT.Events = {
		"change->.menuItem .view input": "viewSwitcher",
		"click->.editor.html .quick_tools img": function() {
			if (isNotEmpty($(this).attr("class")) && $(this).attr("class").indexOf("on") > -1) {
				instance.showAllView(this);
				$(this).attr("src", "/img/arrow-out.png");
			} else {
				instance.resetView(true, false, false, false, this);
				$(this).attr("src", "/img/arrow-in.png");
			}
		},
		"click->.editor.js .quick_tools img": function() {
			if (isNotEmpty($(this).attr("class")) && $(this).attr("class").indexOf("on") > -1) {
				$(this).attr("src", "/img/arrow-out.png");
				instance.showAllView(this);
			} else {
				instance.resetView(false, true, false, false, this);
				$(this).attr("src", "/img/arrow-in.png");
			}
		},
		"click->.editor.css .quick_tools img": function() {
			if (isNotEmpty($(this).attr("class")) && $(this).attr("class").indexOf("on") > -1) {
				$(this).attr("src", "/img/arrow-out.png");
				instance.showAllView(this);
			} else {
				instance.resetView(false, false, true, false, this);
				$(this).attr("src", "/img/arrow-in.png");
			}
		},
		"click->.editor.preview .quick_tools img": function() {
			if (isNotEmpty($(this).attr("class")) && $(this).attr("class").indexOf("on") > -1) {
				$(this).attr("src", "/img/arrow-out.png");
				instance.showAllView(this);
			} else {
				instance.resetView(false, false, false, true, this);
				$(this).attr("src", "/img/arrow-in.png");
			}
		}
	};

	PT.init = function() {

		instance = this;

	};

	PT.onEditorViewInit = function() {
		if (isNotEmpty(instance)) {
			initView();
			addHotKey();
		}
	}

	var addHotKey = function() {
		runjs.addCtrlHotKey({
			'1': {
				event: function(d) {
					instance.resetView(true, false, false, false);
					$(".editor.html .quick_tools img").attr("src", "/img/arrow-in.png");
				},
				data: ''
			},
			'2': {
				event: function(d) {
					instance.resetView(false, true, false, false, this);
					$(".editor.js .quick_tools img").attr("src", "/img/arrow-in.png");
				},
				data: ''
			},
			'3': {
				event: function(d) {
					instance.resetView(false, false, true, false, this);
					$(".editor.css .quick_tools img").attr("src", "/img/arrow-in.png");
				},
				data: ''
			},
			'4': {
				event: function(d) {
					instance.resetView(false, false, false, true, this);
					$(".editor.preview .quick_tools img").attr("src", "/img/arrow-in.png");
				},
				data: ''
			},
			'5': {
				event: function(d) {
					instance.resetView(true, true, true, true, this);
					$(".editor .quick_tools img").attr("src", "/img/arrow-out.png");
				},
				data: ''
			},
		});
	};

	PT.viewSwitcher = function() {
		var v = $(this);
		var id = v.attr('id');
		// 至少要打开一个视图
		if ($(".menuItem .view input:checked").length == 0) {
			v.attr("checked", "checked");
		} else {
			var view = instance.view;
			view[id] = !view[id];
			instance.switchView(view);
		}
	};

	PT.switchView = function(view) {
		var left = true;
		var right = true;
		if (view.html_view) {
			view.left.css({
				width: "50%"
			});
			view.right.css({
				width: "50%"
			});
			view.ver_ctrl.css({
				left: view.left.width() - 5
			});
			if (view.js_view) {
				view.html.css({
					height: "50%"
				});
				view.js.css({
					height: "50%"
				});
			} else {
				view.html.css({
					height: "100%"
				});
				view.js.css({
					height: 0
				});
			}
			view.hor_left.css({
				top: parseInt(view.html.height()) - 5
			});
		} else {
			if (view.js_view) {
				view.left.css({
					width: "50%"
				});
				view.right.css({
					width: "50%"
				});
				view.ver_ctrl.css({
					left: view.left.width() - 5
				});
				view.html.css({
					height: 0
				});
				view.js.css({
					height: "100%"
				});
				view.hor_left.css({
					top: -5
				});
			} else {
				// html和js都不显示
				left = false;
				view.left.css({
					width: 0
				});
				view.right.css({
					width: "100%"
				});
				view.ver_ctrl.css({
					left: -5
				});
			}
		}

		if (view.css_view) {
			if (left) {
				view.left.css({
					width: "50%"
				});
				view.right.css({
					width: "50%"
				});
				view.ver_ctrl.css({
					left: view.left.width() - 5
				});
			}
			if (view.pre_view) {
				view.css.css({
					height: "50%"
				});
				view.preview.css({
					height: "50%"
				});
			} else {
				view.css.css({
					height: "100%"
				});
				view.preview.css({
					height: 0
				});
			}
			view.hor_right.css({
				top: view.css.height() - 5
			});
		} else {
			if (view.pre_view) {
				// css不显示preview显示
				if (left) {
					view.left.css({
						width: "50%"
					});
					view.right.css({
						width: "50%"
					});
					view.ver_ctrl.css({
						left: view.left.width() - 5
					});
				}
				view.css.css({
					height: 0
				});
				view.preview.css({
					height: "100%"
				});
				view.hor_right.css({
					top: -5
				});
			} else {
				// css和preview都不显示
				right = false;
				view.right.css({
					width: 0
				});
				view.left.css({
					width: "100%"
				});
				view.ver_ctrl.css({
					left: view.left.width() - 5
				});
			}
		}
		runjs.editor.refreshEditors();
	};

	PT.resetViewCheckbox = function(view) {
		if (view.html_view) {
			$("#html_view").attr("checked", "checked");
		} else {
			$("#html_view").removeAttr("checked");
		}
		if (view.js_view) {
			$("#js_view").attr("checked", "checked");
		} else {
			$("#js_view").removeAttr("checked");
		}
		if (view.css_view) {
			$("#css_view").attr("checked", "checked");
		} else {
			$("#css_view").removeAttr("checked");
		}
		if (view.pre_view) {
			$("#pre_view").attr("checked", "checked");
		} else {
			$("#pre_view").removeAttr("checked");
		}
	};

	PT.resetView = function(html, js, css, preview, cur) {
		$(cur).addClass("on");
		var view = instance.view;
		view.html_view = html;
		view.js_view = js;
		view.css_view = css;
		view.pre_view = preview;
		instance.resetViewCheckbox(view);
		instance.switchView(view);
	}

	PT.showAllView = function(cur) {
		$(cur).removeClass("on");
		var view = instance.view;
		view.html_view = true;
		view.js_view = true;
		view.css_view = true;
		view.pre_view = true;
		instance.resetViewCheckbox(view);
		instance.switchView(view);
		$(".editor .quick_tools img").attr("src", "/img/arrow-out.png");
	}

	var initView = function() {

		var html = $(".html");
		var js = $(".js");
		var css = $(".css");
		var preview = $(".preview");
		var hor_left = html.parent().find(".handler_horizontal");
		var hor_right = css.parent().find(".handler_horizontal");
		var ver_ctrl = $(".handler_vertical");
		var left = $(".editorSet.left");
		var right = $(".editorSet.right");

		instance.view = {
			html_view: true,
			css_view: true,
			js_view: true,
			pre_view: true,
			ver: {
				left: {
					top: hor_left.css('top'),
					height_top: '50%',
					height_bottom: '50%'
				},
				right: {
					top: 0,
					height_top: 0,
					height_bottom: 0
				}
			},
			hor: {
				left: 0,
				width_left: 0,
				width_right: 0
			},
			html: html,
			js: js,
			hor_left: hor_left,
			css: css,
			preview: preview,
			hor_right: hor_right,
			ver_ctrl: ver_ctrl,
			left: left,
			right: right
		};

	};

});

plugins.newPlugin("7zqdxjtp",ViewSwitcher);
