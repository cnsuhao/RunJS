CMExtraKeyPlugin = (function() {

	var PT = CMExtraKeyPlugin.prototype;

	var instance;

	PT.init = function() {
		instance = this;
	};

	PT.onEditorViewInit = function() {

		var codeFormater = plugins.getPlugin("cv9igin0");

		var htmlCloseTag = plugins.getPlugin("gkrelxmw");

		var codeFolder = plugins.getPlugin("avnuxtyh");

		runjs.editor.editorHtml.setOption("extraKeys", {
			"Shift-Ctrl-F": codeFormater.format,
			"Ctrl-Q": function(cm) {
				codeFolder.foldFunc_html(cm, cm.getCursor().line);
			},
			"'>'": function(cm) {
				cm.closeTag(cm, '>');
			},
			"'/'": function(cm) {
				cm.closeTag(cm, '/');
			}
		});
		runjs.editor.editorJs.setOption("extraKeys", {
			"Shift-Ctrl-F": codeFormater.format,
			"Ctrl-Q": function(cm) {
				codeFolder.foldFunc_js(cm, cm.getCursor().line);
			}
		});
		runjs.editor.editorCss.setOption("extraKeys", {
			"Shift-Ctrl-F": codeFormater.format
		});
	};
});

plugins.newPlugin("gfetqmmn",CMExtraKeyPlugin);