HTMLCloseTag = (function() {

	var PT = HTMLCloseTag.prototype;

	var instance;

	PT.init = function(runjs) {
		instance = this;
		plugins.importJavaScript("/js/CodeMirror-2.25/lib/util/closetag.js");
	};

});

plugins.newPlugin("gkrelxmw",HTMLCloseTag);
