LineHighlight = (function() {

    var PT = LineHighlight.prototype;
    var instance;
    var hlLine;
    var added = false;

    PT.init = function(runjs) {
        instance = this;
    };

    PT.onEditorViewInit = function() {
        if(added)return;
        hlLine = runjs.editor.editorHtml.setLineClass( - 1, "activeline");

        instance.addEvent("onJsCursorActivity",
        function(cm) {
            cm.setLineClass(hlLine, null, null);
            hlLine = cm.setLineClass(cm.getCursor().line, null, "activeline");
        });

        instance.addEvent("onCssCursorActivity",
        function(cm) {
            cm.setLineClass(hlLine, null, null);
            hlLine = cm.setLineClass(cm.getCursor().line, null, "activeline");
        });
        instance.addEvent("onHtmlCursorActivity",
        function(cm) {
            cm.setLineClass(hlLine, null, null);
            hlLine = cm.setLineClass(cm.getCursor().line, null, "activeline");
        });
        added=true;
    }

});

plugins.newPlugin("u3ctfkqz", LineHighlight)