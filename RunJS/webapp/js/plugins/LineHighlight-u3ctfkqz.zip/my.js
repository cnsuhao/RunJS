LineHighlight = (function() {

	var PT = LineHighlight.prototype;
	var instance;
	var hlLine;

	PT.init = function(runjs) {
		instance = this;
	};

	PT.onEditorViewInit = function() {

		hlLine = runjs.editor.editorHtml.setLineClass( - 1, "activeline");

		instance.addEvent("onJsCursorActivity",
		function(cm) {
			cm.setLineClass(hlLine, null, null);
			hlLine = cm.setLineClass(cm.getCursor().line, null, "activeline");
		});

		instance.addEvent("onCssCursorActivity",
		function(cm) {
			cm.setLineClass(hlLine, null, null);
			hlLine = cm.setLineClass(cm.getCursor().line, null, "activeline");
		});
		instance.addEvent("onHtmlCursorActivity",
		function(cm) {
			cm.setLineClass(hlLine, null, null);
			hlLine = cm.setLineClass(cm.getCursor().line, null, "activeline");
		});

	}

});

plugins.newPlugin("u3ctfkqz", LineHighlight)