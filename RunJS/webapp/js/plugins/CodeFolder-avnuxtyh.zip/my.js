CodeFolder = (function() {

	var PT = CodeFolder.prototype;
	var instance;

	PT.init = function(runjs) {
		instance = this;
		plugins.importJavaScript("/js/CodeMirror-2.25/lib/util/foldcode.js");
	};

	PT.onEditorViewInit = function() {

		instance.foldFunc_html = CodeMirror.newFoldFunction(CodeMirror.tagRangeFinder);
		instance.foldFunc_js = CodeMirror.newFoldFunction(CodeMirror.braceRangeFinder);

		runjs.editor.editorJs.setOption("onGutterClick", instance.foldFunc_js);
		runjs.editor.editorHtml.setOption("onGutterClick", instance.foldFunc_html);
	}

});

plugins.newPlugin("avnuxtyh",CodeFolder);
