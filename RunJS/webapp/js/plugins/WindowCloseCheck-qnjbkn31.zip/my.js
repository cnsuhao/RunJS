WindowCloseCheck = (function() {

	var PT = WindowCloseCheck.prototype;

	PT.init = function() {
		$(window).bind('beforeunload',
		function() {
			if (runjs.editor.edited) { 
				return "代码尚未保存，确认离开将不会保存当前数据。";
			}
		}); 
	};

});

plugins.newPlugin("qnjbkn31",WindowCloseCheck);