HTMLFormater = (function() {

	var PT = HTMLFormater.prototype;

	var instance;

	PT.init = function(runjs) {
		instance = this;
		plugins.importJavaScript("/js/js_beautify.js");
	};

	PT.getSelectedRange = function(editor) {
		return {
			from: editor.getCursor(true),
			to: editor.getCursor(false)
		};
	};

	PT.removeJsTagBlank = function() {
		var editor = runjs.editor.editorHtml;
		var line = null,
		ln = 0;
		var startLine = 0;
		while (line = editor.getLine(ln)) {
			try {
				if (startLine == 0 && line.indexOf("<script") > -1 && typeof($(line).attr("class")) != 'undefined' && $(line).attr("class").indexOf("library") > -1) {
					if (line.indexOf("</script>") == -1) startLine = ln;
				} else if (startLine != 0 && line.indexOf("</script>") > -1) {
					var start = editor.getLine(startLine);
					var end = line;
					var blank_start = {
						line: startLine,
						ch: start.length
					};
					var blank_end = {
						line: ln,
						ch: end.indexOf('</')
					};
					editor.replaceRange("", blank_start, blank_end);
					startLine = 0;
					ln--;
				}
			} catch(e) {}
			ln++;
		}
	};

	PT.format = function(cm) {
		var helper = plugins.getPlugin("qhva0jan");
		var cur = helper.focusEditor;
		var gr = instance.getSelectedRange;
		var html = runjs.editor.editorHtml;
		var css = runjs.editor.editorCss;
		var js = runjs.editor.editorJs;
		if (cur != null) {
			if (cur != js) {
				var range = gr(cur);
				if ((range.from.char == range.to.char) && (range.from.line == range.to.line)) {
					CodeMirror.commands["selectAll"](cur);
					range = gr(cur);
				}
				cur.autoFormatRange(range.from, range.to);
				if (cur == html) instance.removeJsTagBlank();
			} else {
				var value = js.getValue();
				var js_source = value.replace(/^\s+/, '');
				var fjs = js_beautify(js_source, 1, '\t');
				js.setValue(fjs);
			}
		}
	}

});

plugins.newPlugin("cv9igin0",HTMLFormater)