ExplorerPlugin = (function() {

	var PT = ExplorerPlugin.prototype;

	PT.Events = {
		"click->.mainresource .js_resource .rurl": "importJs",
		"click->.mainresource .css_resource .rurl": "importCss",
		"click->.mainresource .image_resource .rurl": "importImg",
		"click->.mainresource .other_resource .rurl": "importImg"
	};

	var instance;

	PT.init = function() {
		instance = this;
	}

	PT.onEditorViewInit = function() {
		runjs.editor.editorHtml.setOption("onFocus",
		function(cm) {
			instance.focusEditor = cm;
		});
		runjs.editor.editorCss.setOption("onFocus",
		function(cm) {
			instance.focusEditor = cm;
		});
		runjs.editor.editorJs.setOption("onFocus",
		function(cm) {
			instance.focusEditor = cm;
		});
	}

	PT.importJs = function(cur, e) {
		var href = $(this).attr("href");
		g_utils.insertScriptIntoHead(href,'js');
		g_utils.stopDefault(e);
		return false;  
	};

	PT.importCss = function(cur, e) {
		var href = $(this).attr("href");
		g_utils.insertScriptIntoHead(href,'css');
		g_utils.stopDefault(e);
		return false;
	}

	PT.importImg = function(cur, e) {
		var href = $(this).attr("href");
		var editor = instance.focusEditor;
		if (isNotEmpty(editor)) {
			var range = instance.getSelectedRange(editor);
			editor.replaceRange(href, range.from, range.to);
		}
		g_utils.stopDefault(e);
		return false;
	}
    
	PT.getSelectedRange = function(editor) {
		return {
			from: editor.getCursor(true),
			to: editor.getCursor(false)
		};
	}

});

plugins.newPlugin("qhva0jan",ExplorerPlugin);