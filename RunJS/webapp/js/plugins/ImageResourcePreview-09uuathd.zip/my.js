ImageResourcePreview = (function() {

	var PT = ImageResourcePreview.prototype;

	PT.Events = {
		"mouseover->.image_resource .rurl": "showPreview",
		"mouseout->.image_resource .rurl": "hidePreview"
	};

	PT.init = function() {};

	PT.showPreview = function() {
		$("#image_preview").remove();
		var cur = $(this);
		var url = $(this).attr("href");
		img = $("<img id='image_preview' src='" + url + "' width='100'/>").css({
			left: cur.offset().left + 180,
			top: cur.offset().top,
			position: 'absolute',
			'z-index': 999999
		});
		$("body").append(img);
	};
  
  PT.hidePreview = function(){
  	$("#image_preview").remove();
  };

});

plugins.newPlugin("09uuathd",ImageResourcePreview);
